plotclock
=========

plotclock

a clock that plots time

What you need
-------------
* Lasercutter or 3D Printer

* one Arduino (e.g. uno)

* three RC-Servos Mini (e.g. Tower Pro 9g)

* one whiteboard marker, dry eerasable (e.g. WB SL DRYWIPE MARKER)

* Screws, nuts, washers M3 and a tap for cutting M3.

Assembly
--------

See: http://www.thingiverse.com/thing:248009/#instructions

--

this actually is my first git project, so merging, forks etc. is still new to me and could take some time
